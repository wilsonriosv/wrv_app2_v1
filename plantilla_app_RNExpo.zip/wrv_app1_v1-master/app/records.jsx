// app/records.jsx
import RecordsScreen from "../screens/RecordsScreen";
export default RecordsScreen;