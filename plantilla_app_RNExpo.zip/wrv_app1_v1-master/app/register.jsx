// app/register.jsx
import RegisterScreen from "../screens/RegisterScreen";
export default RegisterScreen;