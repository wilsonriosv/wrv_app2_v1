// app/weather.jsx
import WeatherScreen from "../screens/WeatherScreen";
export default WeatherScreen;