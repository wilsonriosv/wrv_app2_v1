// app/settings.jsx
import SettingsScreen from "../screens/SettingsScreen";
export default SettingsScreen;