// app/login.jsx
import LoginScreen from "../screens/LoginScreen";
export default LoginScreen;