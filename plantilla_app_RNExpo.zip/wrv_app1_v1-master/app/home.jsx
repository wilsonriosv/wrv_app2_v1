// app/home.jsx
import HomeScreen from "../screens/HomeScreen";
export default HomeScreen;